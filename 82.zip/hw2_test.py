import sys
import csv
from math import log

LMFile=open(sys.argv[4],"r")
testFile=open(sys.argv[2],"r")

lm=csv.reader(LMFile, delimiter="\t")

uni=dict()
bi=dict()
'''
with open ("hw2_test.txt", "r") as myfile:
    data=myfile.read().replace('\n', ' ')
test_words= WhitespaceTokenizer().tokenize(data)
test_bigrams = list(filter(('</s>', '<s>').__ne__, nltk.bigrams(test_words)))
fdist_test = nltk.FreqDist(test_bigrams)
sum_pp = 0
for var in fdist_test:
    chk2 = 0
    val2 = 0
    for item in prefix_probs[var[0]]:
        if(item[0] == var[1]):
            chk2 = 1
            val2 = item[1]
    if(chk2 == 1):
        sum_pp = sum_pp + math.log(val2, 2)
    else:
        if(alpha[var[0]] >0):
            #print(alpha[var[0]])
            sum_pp = sum_pp + math.log(alpha[var[0]],2)
            sum_pp = sum_pp + math.log(pOfw.get(var[1]),2)
Nt= len(fdist_test)
minN = -1/Nt
ppl = pow(2,sum_pp*minN)
print(ppl)
'''
mode=""
for line in lm:
    if(line[0]=="##uni##"):
        mode="uni"
        continue
    elif(line[0]=="##bi##"):
        mode="bi"
        continue
    
    if (mode=="uni"):
        uni[line[0]]=[float(line[2]),float(line[3])]

    if (mode=="bi"):
        h=line[0]
        w=line[1]
        if h not in bi:
            bi[h]=dict()
        bi[h][w]=float(line[2])

N=0
sum=0.0
for l in testFile:
    w2=""
    w3=""
    for w in l[:-1].lower().split(" "):
        w=w.strip(' \t\n\r')
        if w=="" or w=="\t":
            continue
    
        N+=1

        if w3!="":
            pass

        ## bigram logic
        if w2!="":
            if w2 in bi:
                if w in bi[w2]:
                    sum+=bi[w2][w]
                else:
                    if (w2 in uni) and (w in uni):
                    
                        sum+=uni[w][0]+uni[w2][1]
                        pass
        
        w3=w2
        w2=w

t1=-sum/float(N)

print("Perplexity:%s"%(2**t1))
